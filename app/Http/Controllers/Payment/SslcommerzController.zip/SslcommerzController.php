<?php

namespace App\Http\Controllers\Payment;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\CombinedOrder;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\WalletController;
use App\Models\CustomerPackage;
use App\Models\SellerPackage;
use App\Http\Controllers\CustomerPackageController;
use App\Http\Controllers\SellerPackageController;
use App\Models\Order;
use App\Models\Cart;
use App\Models\Product;
use App\Models\User;
use App\Models\Preorder;
use Session;
use Auth;
// Mohammad Hassan - Import the official SSLCommerz library
use App\Library\SslCommerz\SslCommerzNotification;

session_start();

class SslcommerzController extends Controller
{

// app/Http/Controllers/Payment/SslcommerzController.php

public function pay(Request $request)
{
    if (!Session::has('payment_type')) {
        flash(translate('Payment session has expired. Please try again.'))->error();
        return redirect()->route('home');
    }

    $user = Auth::user();
    $paymentType = Session::get('payment_type');
    $paymentData = $request->session()->get('payment_data');
    $customer_info = []; 
    $userID = null;
    $combined_order = null;

    if (!$user) {
      
        $userID = 0; 

        if ($paymentType == 'cart_payment' && Session::has('shipping_info_for_order')) {
          
            $customer_info = Session::get('shipping_info_for_order');
        } 
        elseif ($paymentType == 'preorder_payment') {
          
            $data = is_array($paymentData) ? $paymentData : (is_string($paymentData) ? json_decode($paymentData, true) : []);
            $preorderIds = $data['preorder_ids'] ?? Session::get('preorder_ids');
            if ($preorderIds) {
                $first_preorder = Preorder::whereIn('id', is_array($preorderIds) ? $preorderIds : [$preorderIds])->first();
                if ($first_preorder) {
                    $customer_info['name'] = $first_preorder->shipping_name;
                    $customer_info['email'] = $first_preorder->shipping_email;
                    $customer_info['phone'] = $first_preorder->shipping_phone;
                    $customer_info['address'] = $first_preorder->shipping_address;
                    $customer_info['city'] = $first_preorder->shipping_city;
               
                    $customer_info['postal_code'] = $first_preorder->shipping_postal_code ?? '1234';
                }
            }
        }
        else {
           
            return redirect()->route('login')->with('error', 'Please login or provide shipping info to continue.');
        }
        
    } else {
        
        $userID = $user->id;
    }

    $post_data = array();
    $post_data['currency'] = "BDT";
    $post_data['tran_id'] = uniqid();
    $post_data['value_a'] = $post_data['tran_id'];

  
    if ($paymentType == 'cart_payment') {
        $combined_order = CombinedOrder::findOrFail($request->session()->get('combined_order_id'));
        $post_data['total_amount'] = $combined_order->grand_total;
        $post_data['value_b'] = $combined_order->id;
    } elseif ($paymentType == 'preorder_payment') {
        $amount = $paymentData['amount'] ?? 0;
        $post_data['total_amount'] = $amount;
        $post_data['value_b'] = json_encode($paymentData);
    } elseif ($paymentType == 'order_re_payment') {
        $order = Order::findOrFail($paymentData['order_id']);
        $post_data['total_amount'] = $order->grand_total;
        $post_data['value_b'] = $paymentData['order_id'];
    } elseif ($paymentType == 'wallet_payment') {
        $post_data['total_amount'] = $paymentData['amount'];
        $post_data['value_b'] = $paymentData['amount'];
    }
   

    if (!isset($post_data['total_amount']) || $post_data['total_amount'] <= 0) {
        flash(translate('Invalid payment amount. Please try again.'))->error();
        return redirect()->route('home');
    }

    $post_data['value_c'] = $paymentType;
    $post_data['value_d'] = $userID;
    
    $post_data['product_category'] = 'eCommerce';
    $post_data['product_name'] = 'Online Order';
    $post_data['product_profile'] = 'general';
 
    $post_data['cus_name'] = $user ? $user->name : ($customer_info['name'] ?? 'Guest Customer');
    $post_data['cus_email'] = $user ? $user->email : ($customer_info['email'] ?? 'guest@example.com');
    $post_data['cus_add1'] = $user ? ($user->address ?? 'N/A') : ($customer_info['address'] ?? 'N/A');
    $post_data['cus_city'] = $user ? ($user->city ?? 'N/A') : ($customer_info['city'] ?? 'N/A');
    $post_data['cus_country'] = 'Bangladesh';
    $post_data['cus_phone'] = $user ? $user->phone ?? '01000000000' : ($customer_info['phone'] ?? '01000000000');
    $post_data['cus_postcode'] = $user ? ($user->postal_code ?? '1234') : ($customer_info['postal_code'] ?? '1234');
    
    $server_name = $request->root() . "/";
    $post_data['success_url'] = $server_name . "sslcommerz/success";
    $post_data['fail_url'] = $server_name . "sslcommerz/fail";
    $post_data['cancel_url'] = $server_name . "sslcommerz/cancel";
    
    # শিপিং তথ্য (SHIPMENT INFORMATION)
    $shipping_address = [];
    if ($user) {
        if ($combined_order) {
            $shipping_address = json_decode($combined_order->shipping_address, true);
        } else { // ফলব্যাক হিসেবে ব্যবহারকারীর প্রোফাইল তথ্য
            $shipping_address = ['name' => $user->name, 'address' => $user->address, 'city' => $user->city, 'postal_code' => $user->postal_code];
        }
    } else {
        $shipping_address = $customer_info; // অতিথি ব্যবহারকারীর তথ্য
    }
    
    $post_data['shipping_method'] = 'YES';
    $post_data['num_of_item'] = 1; // এটি প্রয়োজন অনুযায়ী পরিবর্তন করতে পারেন
    $post_data['ship_name'] = $shipping_address['name'] ?? $post_data['cus_name'];
    $post_data['ship_add1'] = $shipping_address['address'] ?? $post_data['cus_add1'];
    $post_data['ship_city'] = $shipping_address['city'] ?? $post_data['cus_city'];
    $post_data['ship_country'] = 'Bangladesh';
    $post_data['ship_postcode'] = !empty($shipping_address['postal_code']) ? $shipping_address['postal_code'] : '1234';

    // SslCommerz লাইব্রেরি ব্যবহার করে পেমেন্ট শুরু করা হচ্ছে
    $sslc = new SslCommerzNotification();
    $payment_options = $sslc->makePayment($post_data, 'hosted');
    
    if (!is_array($payment_options)) {
        print_r($payment_options);
    }
}






//    public function pay(Request $request)
//     {
//         # Here you have to receive all the order data to initate the payment.
//         # Lets your oder trnsaction informations are saving in a table called "orders"
//         # In orders table order uniq identity is "order_id","order_status" field contain status of the transaction, "grand_total" is the order amount to be paid and "currency" is for storing Site Currency which will be checked with paid currency.
//         if (Session::has('payment_type')) {
//             // Mohammad Hassan
//             $user = Auth::user();
//             $paymentType = Session::get('payment_type');
//             $paymentData = $request->session()->get('payment_data');
//             $customer = null;

//             if (!$user) {
//                 // Allow guest checkout for preorder payments by deriving customer info from preorder
//                 if ($paymentType === 'preorder_payment') {
//                     $data = is_array($paymentData) ? $paymentData : (is_string($paymentData) ? json_decode($paymentData, true) : []);
//                     $preorderIds = $data['preorder_ids'] ?? Session::get('preorder_ids');
//                     $customer = [
//                         'name' => 'Guest',
//                         'email' => 'guest@example.com',
//                         'phone' => '01000000000',
//                         'address' => 'N/A',
//                         'city' => 'N/A',
//                         'postal_code' => '0000',
//                         'country' => 'Bangladesh',
//                     ];
//                     if ($preorderIds) {
//                         $first = Preorder::whereIn('id', is_array($preorderIds) ? $preorderIds : [$preorderIds])->first();
//                         if ($first) {
//                             $customer['name'] = $first->shipping_name ?: $customer['name'];
//                             $customer['email'] = $first->shipping_email ?: $customer['email'];
//                             $customer['phone'] = $first->shipping_phone ?: $customer['phone'];
//                             $customer['address'] = $first->shipping_address ?: $customer['address'];
//                             $customer['city'] = $first->shipping_city ?: $customer['city'];
//                         }
//                     }
//                     // indicate guest with 0 user id
//                     $userID = 0;
//                 } elseif (Session::has('guest_user_id')) {
//                     $user = User::find(Session::get('guest_user_id'));
//                     if (!$user) {
//                         return redirect()->route('login')->with('error', 'Please login to continue payment.');
//                     }
//                     $userID = $user->id;
//                 } else {
//                     return redirect()->route('login')->with('error', 'Please login to continue payment.');
//                 }
//             } else {
//                 $userID = $user->id;
//             }
//             $post_data = array();
//             $post_data['currency'] = "BDT";
//             $post_data['tran_id'] = substr(md5($userID), 0, 10); // tran_id must be unique
//             $post_data['value_a'] = $post_data['tran_id'];
//             if ($paymentType == 'cart_payment') {
//                 $combined_order = CombinedOrder::findOrFail($request->session()->get('combined_order_id'));
//                 $post_data['total_amount'] = $combined_order->grand_total; # You cant not pay less than 10
//                 $post_data['tran_id'] = substr(md5($request->session()->get('combined_order_id')), 0, 10); // tran_id must be unique
//                 $post_data['value_a'] = $post_data['tran_id'];
//                 $post_data['value_b'] = $request->session()->get('combined_order_id');
//             } elseif ($paymentType == 'order_re_payment') {
//                 $order = Order::findOrFail($paymentData['order_id']);
//                 $post_data['total_amount'] = $order->grand_total; # You cant not pay less than 10
//                 $post_data['value_b'] = $paymentData['order_id'];
//             } elseif ($paymentType == 'wallet_payment') {
//                 $post_data['total_amount'] = $paymentData['amount']; # You cant not pay less than 10
//                 $post_data['value_b'] = $paymentData['amount'];
//             } elseif ($paymentType == 'customer_package_payment') {
//                 $customer_package = CustomerPackage::findOrFail($paymentData['customer_package_id']);
//                 $post_data['total_amount'] = $customer_package->amount; # You cant not pay less than 10
//                 $post_data['value_b'] = $paymentData['customer_package_id'];
//             } elseif ($paymentType == 'seller_package_payment') {
//                 $seller_package = SellerPackage::findOrFail($paymentData['seller_package_id']);
//                 $post_data['total_amount'] = $seller_package->amount; # You cant not pay less than 10
//                 $post_data['value_b'] = $paymentData['seller_package_id'];
//             } elseif ($paymentType == 'preorder_payment') {
//                 // Preorder: use session-stored total
//                 $amount = $request->session()->get('payment_data')['amount'] ?? 0;
//                 $post_data['total_amount'] = $amount;
//                 $post_data['value_b'] = json_encode($request->session()->get('payment_data'));
//             }
            
//             $post_data['value_c'] = $paymentType;
//             $post_data['value_d'] = $userID;
            
//             // Mohammad Hassan - Add required product_category to fix SSLCommerz error
//             $post_data['product_category'] = 'general';
//             $post_data['product_name'] = 'E-commerce Products';
//             $post_data['product_profile'] = 'general';

//             # CUSTOMER INFORMATION
//             // Fallback to guest shipping info when user is not logged in
//             $post_data['cus_name'] = $user ? $user->name : ($customer['name'] ?? 'Guest');
//             $post_data['cus_add1'] = $user ? ($user->address ?? 'N/A') : ($customer['address'] ?? 'N/A');
//             $post_data['cus_city'] = $user ? ($user->city ?? 'N/A') : ($customer['city'] ?? 'N/A');
//             $post_data['cus_postcode'] = $user ? ($user->postal_code ?? '0000') : ($customer['postal_code'] ?? '0000');
//             $post_data['cus_country'] = $user ? ($user->country ?? 'Bangladesh') : ($customer['country'] ?? 'Bangladesh');
//             $post_data['cus_phone'] = $user ? ($user->phone ?? '01000000000') : ($customer['phone'] ?? '01000000000');
//             $post_data['cus_email'] = $user ? ($user->email ?? 'guest@example.com') : ($customer['email'] ?? 'guest@example.com');
//         }

//         // Defensive: ensure total_amount present for preorder flows
//         if (!isset($post_data['total_amount']) || $post_data['total_amount'] <= 0) {
//             if (Session::get('payment_type') === 'preorder_payment') {
//                 $fallbackAmount = Session::get('preorder_total');
//                 if ($fallbackAmount && $fallbackAmount > 0) {
//                     $post_data['total_amount'] = $fallbackAmount;
//                     $post_data['value_c'] = 'preorder_payment';
//                     $post_data['value_b'] = json_encode(Session::get('payment_data', [
//                         'preorder_ids' => Session::get('preorder_ids'),
//                         'amount' => $fallbackAmount
//                     ]));
//                 } else {
//                     flash(translate('Payment session expired or invalid amount for preorder.'))->error();
//                     return redirect()->route('preorder.payment_selection');
//                 }
//             } else {
//                 flash(translate('Payment session expired. Please start checkout again.'))->error();
//                 return redirect()->route('home');
//             }
//         }

//         $server_name = $request->root() . "/";
//         $post_data['success_url'] = $server_name . "sslcommerz/success";
//         $post_data['fail_url'] = $server_name . "sslcommerz/fail";
//         $post_data['cancel_url'] = $server_name . "sslcommerz/cancel";
//         //dd($post_data);
//         # SHIPMENT INFORMATION
//         // Map shipping address to SSLCommerz shipment fields
//         try {
//             $shipping_method = 'NO';
//             $ship = [
//                 'ship_name' => null,
//                 'ship_add1' => null,
//                 'ship_add2' => null,
//                 'ship_city' => null,
//                 'ship_state' => null,
//                 'ship_postcode' => null,
//                 'ship_country' => null,
//             ];

//             if ($paymentType == 'cart_payment') {
//                 $combined_order = CombinedOrder::findOrFail($request->session()->get('combined_order_id'));
//                 $addr = json_decode($combined_order->shipping_address, true);
//             } elseif ($paymentType == 'order_re_payment') {
//                 $order = Order::findOrFail($paymentData['order_id']);
//                 $addr = json_decode($order->shipping_address, true);
//             } else {
//                 $addr = null;
//             }

//             if (is_array($addr)) {
//                 $shipping_method = 'YES';
//                 $ship['ship_name'] = $addr['name'] ?? ($user ? ($user->name ?? 'Customer') : ($customer['name'] ?? 'Customer'));
//                 $ship['ship_add1'] = $addr['address'] ?? ($user ? ($user->address ?? 'N/A') : ($customer['address'] ?? 'N/A'));
//                 $ship['ship_add2'] = $addr['address_line2'] ?? null;
//                 $ship['ship_city'] = $addr['city'] ?? ($user ? ($user->city ?? 'N/A') : ($customer['city'] ?? 'N/A'));
//                 $ship['ship_state'] = $addr['state'] ?? ($user ? ($user->state ?? null) : null);
//                 $ship['ship_postcode'] = $addr['postal_code'] ?? ($user ? ($user->postal_code ?? '0000') : ($customer['postal_code'] ?? '0000'));
//                 $ship['ship_country'] = $addr['country'] ?? ($user ? ($user->country ?? 'Bangladesh') : ($customer['country'] ?? 'Bangladesh'));
//             }

//             // Set mandatory shipment fields
//             $post_data['shipping_method'] = $shipping_method; // YES/NO
//             $post_data['num_of_item'] = 1;
//             foreach ($ship as $k => $v) {
//                 if (!is_null($v)) {
//                     $post_data[$k] = $v;
//                 }
//             }
//         } catch (\Exception $e) {
//             \Log::warning('SSLCommerz shipment mapping failed', ['error' => $e->getMessage()]);
//             $post_data['shipping_method'] = 'NO';
//             $post_data['num_of_item'] = 1;
//         }

//         # OPTIONAL PARAMETERS
//         // $post_data['value_a'] = "ref001";
//         // $post_data['value_b'] = "ref002";
//         // $post_data['value_c'] = "ref003";
//         // $post_data['value_d'] = "ref004";

//         // Mohammad Hassan - Use the official SSLCommerz library
//         $sslc = new SslCommerzNotification();

//         # initiate payment with the official library
//         $payment_options = $sslc->makePayment($post_data, 'hosted');
        
//         if (!is_array($payment_options)) {
//             print_r($payment_options);
//             $payment_options = array();
//         }
//     }

    public function success(Request $request)
    {
        // Mohammad Hassan - Use official SSLCommerz validation with debugging
        $sslc = new SslCommerzNotification();
        
        // Mohammad Hassan - Add debugging logs
        \Log::info('SSLCommerz Success Callback', [
            'request_data' => $request->all(),
            'session_data' => [
                'payment_type' => Session::get('payment_type'),
                'combined_order_id' => Session::get('combined_order_id'),
                'payment_data' => Session::get('payment_data')
            ]
        ]);
        
        #Start to received these value from session. which was saved in index function.
        $tran_id = $request->value_a;
        #End to received these value from session. which was saved in index function.
        $payment = json_encode($request->all());

        # Validate the payment with official library
        $validation = $sslc->orderValidate($request->all(), $tran_id, 0, 'BDT');
        
        // Mohammad Hassan - Log validation result
        \Log::info('SSLCommerz Payment Validation', [
            'tran_id' => $tran_id,
            'validation_result' => $validation,
            'payment_status' => $request->status ?? 'unknown'
        ]);
        
        if ($validation == TRUE) {
            \Log::info('SSLCommerz Payment Validated Successfully', ['tran_id' => $tran_id]);
            
            if (isset($request->value_c)) {
                \Log::info('Processing payment type', ['payment_type' => $request->value_c]);
                
                if ($request->value_c == 'cart_payment') {
                    return (new CheckoutController)->checkout_done($request->value_b, $payment);
                } elseif ($request->value_c == 'order_re_payment') {
                    $data['order_id'] = $request->value_b;
                    $data['payment_method'] = 'sslcommerz';
                    Auth::login(User::find($request->value_d));
                    
                    return (new CheckoutController)->orderRePaymentDone($data, $payment);
                } elseif ($request->value_c == 'wallet_payment') {
                    $data['amount'] = $request->value_b;
                    $data['payment_method'] = 'sslcommerz';
                    Auth::login(User::find($request->value_d));

                    return (new WalletController)->wallet_payment_done($data, $payment);
                } elseif ($request->value_c == 'customer_package_payment') {
                    $data['customer_package_id'] = $request->value_b;
                    $data['payment_method'] = 'sslcommerz';
                    Auth::login(User::find($request->value_d));

                    return (new CustomerPackageController)->purchase_payment_done($data, $payment);
                } elseif ($request->value_c == 'seller_package_payment') {
                    $data['seller_package_id'] = $request->value_b;
                    $data['payment_method'] = 'sslcommerz';
                    Auth::login(User::find($request->value_d));

                    return (new SellerPackageController)->purchase_payment_done(json_decode($request->value_b), $payment);
                } elseif ($request->value_c == 'preorder_payment') {
                    // Guest-friendly: login only if a valid user id is provided
                    $u = User::find($request->value_d);
                    if ($u) {
                        Auth::login($u);
                    }
                    return app(\App\Http\Controllers\Preorder\PreorderController::class)->preorder_payment_success($payment);
                }
            } else {
                \Log::warning('SSLCommerz Success: No payment type found in request', ['request' => $request->all()]);
            }
        } else {
            // Payment validation failed
            \Log::error('SSLCommerz Payment Validation Failed', [
                'tran_id' => $tran_id,
                'request_data' => $request->all()
            ]);
            flash(translate('Payment validation failed'))->error();
            return redirect()->route('home');
        }
    }

    public function fail(Request $request)
    {
        // Mohammad Hassan - Add debugging for payment failures
        \Log::error('SSLCommerz Payment Failed', [
            'request_data' => $request->all(),
            'session_data' => [
                'order_id' => $request->session()->get('order_id'),
                'payment_data' => $request->session()->get('payment_data'),
                'combined_order_id' => $request->session()->get('combined_order_id')
            ]
        ]);
        
        $request->session()->forget('order_id');
        $request->session()->forget('payment_data');
        flash(translate('Payment Failed'))->warning();
        return redirect()->route('home');
    }

    public function cancel(Request $request)
    {
        // Mohammad Hassan - Add debugging for payment cancellations
        \Log::warning('SSLCommerz Payment Cancelled', [
            'request_data' => $request->all(),
            'session_data' => [
                'order_id' => $request->session()->get('order_id'),
                'payment_data' => $request->session()->get('payment_data'),
                'combined_order_id' => $request->session()->get('combined_order_id')
            ]
        ]);
        
        $request->session()->forget('order_id');
        $request->session()->forget('payment_data');
        flash(translate('Payment cancelled'))->error();
        return redirect()->route('home');
    }

    public function ipn(Request $request)
    {
        #Received all the payement information from the gateway
        if ($request->input('tran_id')) #Check transation id is posted or not.
        {

            $tran_id = $request->input('tran_id');

            #Check order status in order tabel against the transaction id or order id.
            $combined_order = CombinedOrder::findOrFail($request->session()->get('combined_order_id'));

            if ($order->payment_status == 'Pending') {
                $sslc = new SSLCommerz();
                $validation = $sslc->orderValidate($tran_id, $order->grand_total, 'BDT', $request->all());
                if ($validation == TRUE) {
                    /*
                        That means IPN worked. Here you need to update order status
                        in order table as Processing or Complete.
                        Here you can also sent sms or email for successfull transaction to customer
                        */
                    echo "Transaction is successfully Complete";
                } else {
                    /*
                        That means IPN worked, but Transation validation failed.
                        Here you need to update order status as Failed in order table.
                        */

                    echo "validation Fail";
                }
            }
        } else {
            echo "Inavalid Data";
        }
    }
}
